#version 330 compatibility
#include "/lib/options.glsl"

out vec3 vWorldPos;
out vec3 vNormal;
out vec4 vColor;
out vec2 vTexCoord;
out vec4 vEntity;

attribute vec4 mc_Entity;

void main() {
    vWorldPos = gl_Vertex.xyz;
    vNormal   = normalize(gl_NormalMatrix * gl_Normal);
    vColor    = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;
    vEntity   = mc_Entity;

    gl_Position = ftransform();
}
