#ifndef QUAD_GLSL
#define QUAD_GLSL

out vec2 texCoord;

void main() {
    gl_Position = ftransform();
    texCoord    = gl_MultiTexCoord0.xy;
}

#endif // QUAD_GLSL
