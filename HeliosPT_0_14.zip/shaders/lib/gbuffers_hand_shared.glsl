// Shared source for gbuffers_hand (first-person held item / arm).
// Each program defines VSH or FSH before including this file.
//
// Without this program Oculus falls back to a generic pipeline that does
// not write colortex0/1/2, so the hand had no albedo/normal/matID for the
// composite passes to read - it showed up as a hole the GI/composite
// stages effectively saw through. This mirrors gbuffers_terrain_shared.glsl
// so the hand is treated as ordinary opaque geometry downstream.
//
// No mc_Entity here: the hand isn't world block geometry, so there is no
// block id to read. matID is written as 0 (same "no special material"
// default terrain uses for plain blocks) rather than left undefined.

#include "/lib/gbuffer_common.glsl"

#ifdef VSH

out vec3 vNormal;
out vec4 vColor;
out vec2 vTexCoord;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;

    vNormal   = normalize(gl_NormalMatrix * gl_Normal);
    vColor    = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;

    gl_Position = gl_ProjectionMatrix * viewPos;
}

#endif

#ifdef FSH

/* RENDERTARGETS: 0,1,2 */
in vec3 vNormal;
in vec4 vColor;
in vec2 vTexCoord;

uniform sampler2D tex;

void main() {
    vec4 albedo = texture2D(tex, vTexCoord) * vColor;
    if (albedo.a < 0.1) discard;

    vec3 normal = normalize(vNormal);

    gl_FragData[0] = albedo;                                             // colortex0: albedo
    gl_FragData[1] = vec4(encodeNormal(normal), 1.0);                    // colortex1: normal
    gl_FragData[2] = vec4(encodeDepth(gl_FragCoord.z), 0.0, 0.0, 1.0);   // colortex2: depth+id (matID 0 = no special material)
}

#endif
