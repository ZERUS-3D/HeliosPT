#ifndef OPTIONS_GLSL
#define OPTIONS_GLSL

// ---------------------------------------------------------------------------
// User-facing options. Values after // [ ... ] populate the in-game slider.
// These macros are also evaluated by shaders.properties for profiles/scales.
// ---------------------------------------------------------------------------
#define VOXEL_GRID          1   // [0 1 2] 0:64³, 1:96³, 2:128³
#define GI_RESOLUTION       1   // [0 1 2] 0:0.5x, 1:0.75x, 2:1.0x
#define DDA_STEPS           1   // [0 1 2] 0:32, 1:64, 2:128
#define MAX_BOUNCES         1   // [1 2 3]
#define ATROUS_PASSES       4   // [3 4 5]
#define EXPOSURE_BIAS       0   // [-5 -4 -3 -2 -1 0 1 2 3 4 5]
#define SUN_LIGHT_INTENSITY 1.0 // [0.5 0.75 1.0 1.25 1.5]
#define DEBUG_MODE          0   // [0 1 2 3 4] 0:off 1:voxels 2:GI 3:albedo 4:normals

#define VX_BLOCK_ID 1

// ---------------------------------------------------------------------------
// Derived constants — resolved at compile time so the compiler can unroll loops.
// ---------------------------------------------------------------------------
#if VOXEL_GRID == 0
  #define VX_SIZE 64
#elif VOXEL_GRID == 1
  #define VX_SIZE 96
#else
  #define VX_SIZE 128
#endif

#if DDA_STEPS == 0
  #define MAX_DDA 32
#elif DDA_STEPS == 1
  #define MAX_DDA 64
#else
  #define MAX_DDA 128
#endif

#if GI_RESOLUTION == 0
  #define GI_SCALE 0.5
#elif GI_RESOLUTION == 1
  #define GI_SCALE 0.75
#else
  #define GI_SCALE 1.0
#endif

#endif // OPTIONS_GLSL
