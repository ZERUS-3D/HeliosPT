#ifndef UTIL_GLSL
#define UTIL_GLSL

#include "/lib/options.glsl"

// ---------------------------------------------------------------------------
// Uniforms — SINGLE SOURCE OF TRUTH for composite/deferred/final programs.
//
// IMPORTANT finding for Oculus 1.6.4 (log 2026-09-10):
//   This loader does NOT auto-inject OptiFine uniform declarations (older
//   Iris fork). Every uniform used MUST be declared by the pack, but EXACTLY
//   ONCE per compiled program. The earlier "C1038 conflicts" errors were our
//   OWN duplicates across includes (util.glsl vs voxel.glsl vs noise.glsl),
//   not loader injection. Other includes therefore must not redeclare these:
//   they rely on the HELIOS_UNIFORMS_DECLARED guard below.
// ---------------------------------------------------------------------------
#define HELIOS_UNIFORMS_DECLARED

uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;

uniform int   frameCounter;

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;

uniform sampler2D depthtex0;
uniform sampler2D shadowcolor0;

uniform sampler2D colortex0;  // albedo
uniform sampler2D colortex1;  // world-space normal
uniform sampler2D colortex2;  // linear depth + material ID
uniform sampler2D colortex3;  // reserved
uniform sampler2D colortex4;  // GI radiance
uniform sampler2D colortex5;  // GI second moment
uniform sampler2D colortex6;  // filtered GI / temporal history
uniform sampler2D colortex7;  // history moment

// ---------------------------------------------------------------------------
// Depth / position helpers
// ---------------------------------------------------------------------------
float linearDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

float encodeDepth(float depth) { return depth / far; }
float decodeDepth(float depth) { return depth * far; }

vec3 encodeNormal(vec3 n) { return n * 0.5 + 0.5; }
vec3 decodeNormal(vec3 n) { return n * 2.0 - 1.0; }

vec3 getWorldPos(vec2 uv, float depth) {
    vec4 ndc  = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * ndc;
    view /= view.w;
    vec4 world = gbufferModelViewInverse * view;
    return world.xyz;
}

vec3 getViewDir(vec2 uv) {
    return normalize(getWorldPos(uv, 0.0));
}

// ---------------------------------------------------------------------------
// Simple frame-coherent hash noise (Pascal-friendly, no texture fetch)
// ---------------------------------------------------------------------------
float interleavedGradientNoise(vec2 uv) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(uv, magic.xy)));
}

#endif // UTIL_GLSL
