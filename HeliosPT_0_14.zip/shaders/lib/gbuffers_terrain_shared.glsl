// Shared source for:
//   gbuffers_terrain, gbuffers_terrain_cutout, gbuffers_terrain_cutout_mipped
// Each program defines VSH or FSH before including this file.

#include "/lib/gbuffer_common.glsl"

attribute vec4 mc_Entity;

#ifdef VSH

out vec3 vWorldPos;
out vec3 vNormal;
out vec4 vColor;
out vec2 vTexCoord;
out vec4 vEntity;

void main() {
    vec4 viewPos  = gl_ModelViewMatrix * gl_Vertex;
    vec4 worldPos = gbufferModelViewInverse * viewPos;

    vWorldPos = worldPos.xyz;
    vNormal   = normalize(gl_NormalMatrix * gl_Normal);
    vColor    = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;
    vEntity   = mc_Entity;

    gl_Position = gl_ProjectionMatrix * viewPos;
}

#endif

#ifdef FSH

/* RENDERTARGETS: 0,1,2 */
in vec3 vWorldPos;
in vec3 vNormal;
in vec4 vColor;
in vec2 vTexCoord;
in vec4 vEntity;

uniform sampler2D tex;

void main() {
    vec4 albedo = texture2D(tex, vTexCoord) * vColor;
    if (albedo.a < 0.1) discard;

    vec3 normal = normalize(vNormal);
    float matID = clamp(vEntity.x / 255.0, 0.0, 1.0);

    gl_FragData[0] = albedo;                                               // colortex0: albedo
    gl_FragData[1] = vec4(encodeNormal(normal), 1.0);                      // colortex1: normal
    gl_FragData[2] = vec4(encodeDepth(gl_FragCoord.z), matID, 0.0, 1.0);   // colortex2: depth+id
}

#endif
