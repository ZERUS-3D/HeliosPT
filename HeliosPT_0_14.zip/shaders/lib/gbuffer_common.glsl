#ifndef GBUFFER_COMMON_GLSL
#define GBUFFER_COMMON_GLSL

// Minimal include for gbuffers programs (they never include util.glsl, so
// composite-only samplers such as colortex3..7 stay out of these stages).
// Oculus 1.6.4 does not auto-inject uniforms: declare here, exactly once.

#include "/lib/options.glsl"

uniform float near;
uniform float far;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;

vec3 encodeNormal(vec3 n) { return n * 0.5 + 0.5; }
float encodeDepth(float d) { return d / far; }

#endif // GBUFFER_COMMON_GLSL
