#version 330 compatibility
#include "/lib/options.glsl"

// Runs once per frame, before the shadow pass rasterizes shadow.gsh's
// voxel points. Iris/Oculus color buffers persist across frames by
// default - without an explicit clear here, any voxel cell that shadow.gsh
// does not touch this frame (e.g. it fell outside the shadow pass's own
// render distance, which can be smaller than the VX_SIZE grid radius)
// keeps whatever occupancy/color it had from a PREVIOUS frame, at a
// DIFFERENT world position, because the atlas is indexed relative to the
// current camera-centered grid (voxelToUV / VX_HALF). As the player moves,
// that stale data reads as a solid voxel occupying the wrong place - a
// dark, block-aligned patch that steps along with player movement, which
// is exactly the "cube-shaped darker area that shifts block-by-block"
// artifact reported after ruling out temporal reprojection (composite1
// with blend forced to 0 still showed it).
/* RENDERTARGETS: 0 */
out vec4 color;

void main() {
    color = vec4(0.0); // a = 0 -> voxelOccupied() reads this cell as empty
}
