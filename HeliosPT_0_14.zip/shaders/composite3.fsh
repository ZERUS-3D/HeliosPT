#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"

/* RENDERTARGETS: 4,5 */
in vec2 texCoord;

// Same binomial kernel as composite2, function form (avoids C1033).
float kernelWeight(int i) {
    if (i == 0) return 0.375;
    if (i == 1 || i == -1) return 0.25;
    return 0.0625;
}

vec3 aTrousStep(sampler2D src, int stepSize) {
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);

    vec3  cCenter = texture2D(src, texCoord).rgb;
    float dCenter = linearDepth(texture2D(depthtex0, texCoord).r);
    vec3  nCenter = decodeNormal(texture2D(colortex1, texCoord).rgb);

    vec3  sum  = cCenter * kernelWeight(0);
    float wSum = kernelWeight(0);

    for (int x = -2; x <= 2; ++x) {
        for (int y = -2; y <= 2; ++y) {
            if (x == 0 && y == 0) continue;
            vec2 sUV = texCoord + vec2(float(x), float(y)) * float(stepSize) * texel;

            vec3  sC = texture2D(src, sUV).rgb;
            float sD = linearDepth(texture2D(depthtex0, sUV).r);
            vec3  sN = decodeNormal(texture2D(colortex1, sUV).rgb);

            float w = kernelWeight(x) * kernelWeight(y);
            // Same fix as composite2.fsh: normalized + steeper falloff,
            // hard-cut on weak edge weight so distant silhouettes don't
            // pick up color from whatever is behind them.
            float wZ = exp(-abs(sD - dCenter) / max(dCenter, 1e-4) * 80.0);
            float wN = pow(max(dot(sN, nCenter), 0.0), 32.0);
            if (wZ * wN < 0.05) continue;
            w *= wZ * wN;

            sum  += sC * w;
            wSum += w;
        }
    }
    return sum / max(wSum, 1e-5);
}

void main() {
    // Input: A-Trous output from composite2 (colortex6).
    vec3 result = texture2D(colortex6, texCoord).rgb;

    #if ATROUS_PASSES >= 3
        vec3 pass3 = aTrousStep(colortex6, 4);
        result = mix(result, pass3, 0.5);
    #endif
    #if ATROUS_PASSES >= 4
        vec3 pass4 = aTrousStep(colortex6, 8);
        result = mix(result, pass4, 0.33);
    #endif
    #if ATROUS_PASSES >= 5
        vec3 pass5 = aTrousStep(colortex6, 16);
        result = mix(result, pass5, 0.25);
    #endif

    gl_FragData[0] = vec4(result, 1.0);          // colortex4 — final filtered GI
    gl_FragData[1] = vec4(result * result, 1.0); // colortex5 — moment
}
