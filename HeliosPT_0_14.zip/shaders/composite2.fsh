#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"

/* RENDERTARGETS: 6,7 */
in vec2 texCoord;

// 5-tap binomial kernel (1,4,6,4,1)/16 expressed as a function instead of a
// const-array constructor. NVIDIA's GLSL parser in the Oculus compatibility
// profile rejected `const float h[5] = float[](...)` with
// "error C1033: cast not allowed".
float kernelWeight(int i) {
    if (i == 0) return 0.375;             // 6/16
    if (i == 1 || i == -1) return 0.25;   // 4/16
    return 0.0625;                        // 1/16 (i == +/-2)
}

vec4 aTrousPass(sampler2D srcColor, sampler2D srcMoment, int stepSize) {
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);

    vec3  cCenter = texture2D(srcColor, texCoord).rgb;
    float dCenter = linearDepth(texture2D(depthtex0, texCoord).r);
    vec3  nCenter = decodeNormal(texture2D(colortex1, texCoord).rgb);

    vec3  sum  = cCenter * kernelWeight(0);
    float wSum = kernelWeight(0);

    for (int x = -2; x <= 2; ++x) {
        for (int y = -2; y <= 2; ++y) {
            if (x == 0 && y == 0) continue;
            vec2 sUV = texCoord + vec2(float(x), float(y)) * float(stepSize) * texel;

            vec3  sC = texture2D(srcColor, sUV).rgb;
            float sV = texture2D(srcMoment, sUV).r;
            float sD = linearDepth(texture2D(depthtex0, sUV).r);
            vec3  sN = decodeNormal(texture2D(colortex1, sUV).rgb);

            float w = kernelWeight(x) * kernelWeight(y);

            // Edge-stopping weights: depth, normal, variance.
            // wZ was exp(-abs(dz)*2.0) - too soft at distance, letting a
            // background surface (or a different object) bleed color
            // across silhouette edges. Normalizing by dCenter and using a
            // steeper falloff makes the stop scale with distance instead
            // of staying loose the farther the surface is from camera.
            float wZ = exp(-abs(sD - dCenter) / max(dCenter, 1e-4) * 80.0);
            float wN = pow(max(dot(sN, nCenter), 0.0), 32.0);
            float wV = 1.0 / (1.0 + sqrt(max(sV, 0.0)) * 4.0);
            w *= wZ * wN * wV;

            // Hard-cut near-zero edge weights instead of letting them limp
            // through the weighted sum - this is what actually stops the
            // colored fringe on far edges, not just the softer falloff above.
            if (wZ * wN < 0.05) continue;

            sum  += sC * w;
            wSum += w;
        }
    }

    return vec4(sum / max(wSum, 1e-5), 1.0);
}

void main() {
    // Input: temporal GI in colortex4/5 (from composite1).
    // Output: filtered GI in colortex6/7, which composite1 of the NEXT frame
    // reads as history. Nothing else may overwrite 6/7 this frame.
    vec4 pass0 = aTrousPass(colortex4, colortex5, 1);
    vec4 pass1 = aTrousPass(colortex4, colortex5, 2);

    vec3 filtered = mix(pass0.rgb, pass1.rgb, 0.5);
    vec3 moment   = pass1.rgb * pass1.rgb;

    gl_FragData[0] = vec4(filtered, 1.0); // colortex6 — filtered GI / history
    gl_FragData[1] = vec4(moment, 1.0);   // colortex7 — history moment
}
