# HeliosPT — shader pack files

This folder **is** the shader pack. When zipped, it must sit at the archive
root: `HeliosPT.zip/shaders/...` (see ../INSTALL.md and ../README.md).

Pipeline overview:

| Stage | Files | Purpose |
|-------|-------|---------|
| Voxelization | `shadow.vsh/.gsh/.fsh` | Block triangles → points in a 2D voxel atlas |
| G-buffer | `gbuffers_terrain*` | MRT: albedo (CT0), normals (CT1), depth+id (CT2) |
| Path tracing | `composite.fsh` | Integer 3D DDA, diffuse GI, 1–2 bounces |
| Temporal | `composite1.fsh` | Camera-motion reprojection |
| Denoiser | `composite2.fsh`, `composite3.fsh` | A-Trous / SVGF-style edge-aware filtering |
| Compositing | `final.fsh` | Procedural sky, exposure, ACES tonemap |

Options: `lib/options.glsl`. Voxel atlas + DDA: `lib/voxel.glsl`.
Changelog and task list: `ROADMAP.md`. Debug protocol: `../DEBUGGING.md`.
