#version 330 compatibility
#include "/lib/options.glsl"

/* RENDERTARGETS: 0 */
in vec4 color;

void main() {
    // Stored in shadowcolor0: rgb = averaged block color, a = occupancy.
    gl_FragData[0] = vec4(color.rgb, 1.0);
}
