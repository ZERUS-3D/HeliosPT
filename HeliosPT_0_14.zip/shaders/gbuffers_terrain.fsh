#version 330 compatibility
#define FSH
#include "/lib/gbuffers_terrain_shared.glsl"
