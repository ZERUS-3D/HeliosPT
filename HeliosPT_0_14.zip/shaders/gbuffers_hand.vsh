#version 330 compatibility
#define VSH
#include "/lib/gbuffers_hand_shared.glsl"
