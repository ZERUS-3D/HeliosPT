#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"
#include "/lib/voxel.glsl"
#include "/lib/noise.glsl"
#include "/lib/color.glsl"

/* RENDERTARGETS: 4,5 */
in vec2 texCoord;

const vec3 SKY_DAY_COLOR = vec3(0.25, 0.42, 0.75);
const vec3 SUN_COLOR     = vec3(1.0, 0.95, 0.82);
const vec3 MOON_COLOR    = vec3(0.45, 0.55, 0.85);

vec3 getSkyLightDir() {
    // sunPosition / moonPosition arrive in view space; tracing happens in
    // camera-relative world space -> rotate them back.
    vec3 sunWorld  = mat3(gbufferModelViewInverse) * sunPosition;
    vec3 moonWorld = mat3(gbufferModelViewInverse) * moonPosition;
    return (sunWorld.y > 0.0) ? normalize(sunWorld) : normalize(moonWorld);
}

vec3 getSkyLightColor() {
    vec3 sunWorld = mat3(gbufferModelViewInverse) * sunPosition;
    return (sunWorld.y > 0.0) ? SUN_COLOR : MOON_COLOR;
}

vec3 evalSky(vec3 rayDir, vec3 lightDir, vec3 lightColor) {
    float horizon = pow(clamp(rayDir.y * 0.5 + 0.5, 0.0, 1.0), 0.8);
    vec3 sky = mix(vec3(0.55, 0.62, 0.72) * 0.25, SKY_DAY_COLOR, horizon);
    float disk = pow(max(dot(rayDir, lightDir), 0.0), 512.0);
    sky += lightColor * disk * 4.0 * SUN_LIGHT_INTENSITY;
    return sky;
}

void main() {
    vec2 uv = texCoord;
    float depth = texture2D(depthtex0, uv).r;
    vec4 albedo = texture2D(colortex0, uv);

    // Background pixels: no path tracing, the sky is drawn in final.fsh.
    if (depth >= 1.0) {
        gl_FragData[0] = vec4(0.0);
        gl_FragData[1] = vec4(0.0);
        return;
    }

    vec3 worldPos = getWorldPos(uv, depth);
    vec3 normal   = decodeNormal(texture2D(colortex1, uv).rgb);

    // Was seededNoise(gl_FragCoord.xy): screen-space pixel coords, so the
    // SAME world surface got a totally different random ray direction the
    // instant it moved to a different pixel - which happens on every pure
    // camera rotation, not just player movement. The raw GI result then
    // jumped between frames even when nothing in the world had changed,
    // showing up as flicker/glow that tracked camera turning specifically
    // (worse at distance, where the flat ambient/sky floor made the swing
    // more visible against a darker background).
    // worldPos + cameraPosition is the true world-space point (worldPos
    // alone is camera-relative and would drift with camera movement too),
    // so the same physical surface now gets the same seed base regardless
    // of where it lands on screen or how the camera has moved.
    vec2 seed       = seededNoise((worldPos + cameraPosition).xz * 4.0
                                 + (worldPos + cameraPosition).y * 7.0);
    vec3 lightDir   = getSkyLightDir();
    vec3 lightColor = getSkyLightColor();

    vec3 origin     = worldPos + normal * 0.05;
    vec3 radiance   = vec3(0.0);
    vec3 throughput = vec3(1.0);
    vec3 hitNormal  = normal;

    for (int bounce = 0; bounce <= MAX_BOUNCES; ++bounce) {
        vec3 bounceN = (bounce == 0) ? normal : hitNormal;
        vec3 rayDir  = cosineSampleHemisphere(bounceN, seed + vec2(float(bounce) * 0.71));

        VoxelHit hit = traceVoxelRay(origin, rayDir, bounce == 0);

        if (!hit.hit) {
            if (hit.escapedBounds) {
                // Ran past the finite voxel grid radius without a confirmed
                // hit or a confirmed line to open air - NOT the same as
                // real sky. Previously this added full evalSky() (including
                // the sun disk), which let bright "sky" leak through solid
                // rock at a fixed distance underground and flickered as
                // random bounce directions crossed the boundary each frame.
                // A dim, sun-less ambient is a safer unknown-value guess.
                radiance += throughput * vec3(0.08, 0.09, 0.1);
            } else {
                radiance += throughput * evalSky(rayDir, lightDir, lightColor);
            }
            break;
        }

        // Direct sky light visibility from the hit point. Only count the
        // sun as visible on a CONFIRMED miss - if the shadow ray merely
        // left the grid radius, we don't actually know whether something
        // blocks it further out, so don't light the surface as if it does.
        VoxelHit sunHit = traceVoxelRay(hit.pos + hit.normal * 0.05, lightDir, false);
        if (!sunHit.hit && !sunHit.escapedBounds) {
            float NdotL = max(dot(hit.normal, lightDir), 0.0);
            // Irradiance only (albedo applied later), scale by pi cancels
            // the cosine-sampling PDF normalization.
            radiance += throughput * lightColor * NdotL * 3.14159 * SUN_LIGHT_INTENSITY;
        }

        // Indirect bounce energy carries the hit albedo.
        throughput *= hit.color.rgb;
        origin      = hit.pos + hit.normal * 0.05;
        hitNormal   = hit.normal;

        // Early path termination on dim paths saves Pascal FP32 cycles.
        if (bounce >= 1) {
            float pSurvive = clamp(max(throughput.r, max(throughput.g, throughput.b)),
                                   0.05, 0.95);
            if (hash12(seed + float(bounce) * 37.0) > pSurvive) break;
            throughput /= pSurvive;
        }
    }

    // Small ambient floor so deep interiors never clip to absolute black.
    // Was 0.06 - too faint to read as "lit" once ACES + gamma compress it.
    radiance += vec3(0.12);

    gl_FragData[0] = vec4(radiance, 1.0);
    gl_FragData[1] = vec4(radiance * radiance, 1.0);
}
