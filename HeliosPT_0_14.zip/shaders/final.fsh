#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"
#include "/lib/voxel.glsl"
#include "/lib/color.glsl"

in vec2 texCoord;

const vec3 SKY_TOP  = vec3(0.20, 0.38, 0.75);
const vec3 SKY_HOR  = vec3(0.62, 0.70, 0.85);
const vec3 SUN_COL  = vec3(1.0, 0.93, 0.78);
const vec3 MOON_COL = vec3(0.40, 0.50, 0.80);

vec3 renderSky(vec3 viewDirWorld) {
    vec3 sunWorld  = mat3(gbufferModelViewInverse) * sunPosition;
    bool day       = sunWorld.y > 0.0;
    vec3 lightDir  = day ? normalize(sunWorld)
                         : normalize(mat3(gbufferModelViewInverse) * moonPosition);
    vec3 lightCol  = day ? SUN_COL : MOON_COL;

    float t = clamp(viewDirWorld.y * 0.5 + 0.55, 0.0, 1.0);
    vec3 sky = mix(SKY_HOR, SKY_TOP, pow(t, 0.9));
    if (!day) sky *= 0.25;

    float disk = pow(max(dot(viewDirWorld, lightDir), 0.0), 1024.0);
    float glow = pow(max(dot(viewDirWorld, lightDir), 0.0), 8.0) * 0.12;
    sky += lightCol * (disk * 3.0 + glow) * SUN_LIGHT_INTENSITY;
    return sky;
}

vec3 worldDirFromUV(vec2 uv) {
    vec4 farPos = vec4(uv * 2.0 - 1.0, 1.0, 1.0);
    vec4 view   = gbufferProjectionInverse * farPos;
    return normalize((gbufferModelViewInverse * view).xyz);
}

void main() {
    vec2  uv     = texCoord;
    float depth  = texture2D(depthtex0, uv).r;
    vec4  albedo = texture2D(colortex0, uv);

    vec3 color;

#if DEBUG_MODE == 1
    // --- Voxel grid debug: DDA ray straight from the camera eye. ---
    // Hit -> stored voxel color (brightened); miss -> dark blue.
    vec3 dbgDir = worldDirFromUV(uv);
    VoxelHit dbgHit = traceVoxelRay(vec3(0.0), dbgDir, false);
    color = dbgHit.hit ? dbgHit.color.rgb * 2.0
                       : vec3(0.05, 0.05, 0.20);
#elif DEBUG_MODE == 2
    // Raw / denoised GI buffer as-is.
    color = texture2D(colortex4, uv).rgb;
#elif DEBUG_MODE == 3
    // G-buffer albedo.
    color = albedo.rgb;
#elif DEBUG_MODE == 4
    // Encoded world-space normals.
    color = texture2D(colortex1, uv).rgb;
#else
    if (depth >= 1.0) {
        // Background -> procedural sky.
        color = renderSky(worldDirFromUV(uv));
    } else {
        vec3 gi   = texture2D(colortex4, uv).rgb;
        vec3 nEnc = texture2D(colortex1, uv).rgb;
        bool hasN = length(nEnc - 0.5) > 0.02;

        // Remaining fixed-function geometry (entities, water until their
        // shaders exist) has no normal / no GI: flat ambient floor keeps
        // it visible. gbuffers_hand now covers the held item/arm, so that
        // case takes the hasN branch like normal terrain.
        vec3 giFloor = hasN ? vec3(0.1)
                            : vec3(0.55, 0.58, 0.65) * 0.55;
        color = albedo.rgb * max(gi, giFloor);
    }

    // Auto-exposure with the hard clamp from the design doc.
    // Was a single texel at (0.5,0.5): one noisy path-traced sample with no
    // temporal filtering of its own, so exposure flickered with the GI
    // noise even on a static camera. Averaging a small neighborhood costs
    // a handful of extra fetches but kills most of that per-frame jitter.
    vec3 centerSample = vec3(0.0);
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
    for (int ex = -1; ex <= 1; ++ex) {
        for (int ey = -1; ey <= 1; ++ey) {
            vec2 euv = vec2(0.5) + vec2(float(ex), float(ey)) * texel * 4.0;
            centerSample += texture2D(colortex0, euv).rgb *
                            max(texture2D(colortex4, euv).rgb, vec3(0.2));
        }
    }
    centerSample /= 9.0;
    color *= getAutoExposure(centerSample);
#endif

    color = acesToneMap(color);
    color = pow(max(color, vec3(0.0)), vec3(1.0 / 2.2));

    gl_FragData[0] = vec4(color, 1.0);
}
