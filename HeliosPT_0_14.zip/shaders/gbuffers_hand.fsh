#version 330 compatibility
#define FSH
#include "/lib/gbuffers_hand_shared.glsl"
