#version 330 compatibility
#define VSH
#include "/lib/gbuffers_terrain_shared.glsl"
