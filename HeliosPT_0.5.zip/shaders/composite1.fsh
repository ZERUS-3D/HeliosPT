#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"

/* RENDERTARGETS: 4,5 */
in vec2 texCoord;

void main() {
    vec2 uv = texCoord;

    // Raw path-traced GI + moments from composite.
    vec4 curIrr  = texture2D(colortex4, uv);
    vec4 curMom2 = texture2D(colortex5, uv);

    float depth    = texture2D(depthtex0, uv).r;
    vec3  worldPos = getWorldPos(uv, depth);              // camera-relative
    vec3  normal   = decodeNormal(texture2D(colortex1, uv).rgb);

    // Reproject into the PREVIOUS camera frame: translate from the current
    // camera-relative origin to the previous one before applying previous
    // matrices, otherwise history is rejected the moment the player moves.
    vec3 prevWorld = worldPos + cameraPosition - previousCameraPosition;
    vec4 prevClip  = gbufferPreviousProjection * gbufferPreviousModelView
                   * vec4(prevWorld, 1.0);
    vec2 prevUV    = prevClip.xy / prevClip.w * 0.5 + 0.5;

    // History is the A-Trous-filtered output of composite2 from last frame
    // (colortex6/7), not the unfiltered temporal buffer.
    vec4 histIrr  = texture2D(colortex6, prevUV);
    vec4 histMom2 = texture2D(colortex7, prevUV);

    float blend = 0.92;

    // Off-screen history.
    if (any(lessThan(prevUV, vec2(0.0))) || any(greaterThan(prevUV, vec2(1.0))))
        blend = 0.0;

    // Depth of the reprojected surface vs. current pixel (relative threshold
    // tolerates far geometry, absolute floor protects near-field edges).
    float prevDepthNdc = clamp(prevClip.z / prevClip.w * 0.5 + 0.5, 0.0, 1.0);
    float prevZ = linearDepth(prevDepthNdc);
    float curZ  = linearDepth(depth);
    if (abs(prevZ - curZ) > max(0.02 * curZ, 0.02))
        blend = 0.0;

    // Normal discontinuity also invalidates history.
    vec3 prevNormal = decodeNormal(texture2D(colortex1, prevUV).rgb);
    if (dot(prevNormal, normal) < 0.9)
        blend = 0.0;

    gl_FragData[0] = mix(curIrr,  histIrr,  blend);  // colortex4 — temporal GI
    gl_FragData[1] = mix(curMom2, histMom2, blend);  // colortex5 — moment
}
