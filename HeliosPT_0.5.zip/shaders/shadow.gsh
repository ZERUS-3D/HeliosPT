#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/voxel.glsl"

layout(triangles) in;
layout(points, max_vertices = 1) out;

in vec3 vWorldPos[];
in vec3 vNormal[];
in vec4 vColor[];
in vec2 vTexCoord[];
in vec4 vEntity[];

out vec4 color;

uniform sampler2D tex;

void main() {
    // Only voxelize blocks that received an ID in block.properties.
    if (int(vEntity[0].x + 0.5) != VX_BLOCK_ID) return;

    vec3 triNormal = normalize(cross(vWorldPos[1] - vWorldPos[0],
                                     vWorldPos[2] - vWorldPos[0]));
    vec3 centroid  = (vWorldPos[0] + vWorldPos[1] + vWorldPos[2]) * 0.333333;

    // Push slightly inward so voxels do not leak out of solid faces.
    vec3 within    = centroid + fract(cameraPosition) - triNormal * 0.1;
    ivec3 rounded  = ivec3(floor(within));
    ivec3 centered = rounded + ivec3(VX_HALF);

    if (!voxelInBounds(centered)) return;

    gl_Position  = vec4(voxelToNDC(centered), 0.0, 1.0);
    gl_PointSize = 1.0;

    vec2 texcoord = (vTexCoord[0] + vTexCoord[1] + vTexCoord[2]) * 0.333333;
    color = ((vColor[0] + vColor[1] + vColor[2]) * 0.333333) * texture2D(tex, texcoord);

    EmitVertex();
    EndPrimitive();
}
