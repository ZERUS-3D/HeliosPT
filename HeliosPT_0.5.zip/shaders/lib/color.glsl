#ifndef COLOR_GLSL
#define COLOR_GLSL

#include "/lib/options.glsl"

const float EXPOSURE_MIN = 0.3;
const float EXPOSURE_MAX = 1.5;

// ---------------------------------------------------------------------------
// ACES-inspired tonemapper with soft highlight compression.
// Keeps white windows from burning and interiors from clipping to black.
// ---------------------------------------------------------------------------
vec3 acesToneMap(vec3 x) {
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// ---------------------------------------------------------------------------
// Auto-exposure with hard clamp. Uses center-screen luminance as a cheap
// stand-in; real packs should use a dedicated 1×1 luminance target.
// ---------------------------------------------------------------------------
float getAutoExposure(vec3 centerSample) {
    float luma    = max(dot(centerSample, vec3(0.2126, 0.7152, 0.0722)), 1e-5);
    float target  = 0.18;
    float expBias = float(EXPOSURE_BIAS) * 0.1;
    return clamp(target / luma + expBias, EXPOSURE_MIN, EXPOSURE_MAX);
}

#endif // COLOR_GLSL
