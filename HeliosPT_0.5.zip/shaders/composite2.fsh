#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"

/* RENDERTARGETS: 6,7 */
in vec2 texCoord;

// 5-tap A-Trous filter kernel.
const float h[5] = float[](1.0 / 16.0, 1.0 / 4.0, 3.0 / 8.0, 1.0 / 4.0, 1.0 / 16.0);

vec4 aTrousPass(sampler2D srcColor, sampler2D srcMoment, int step) {
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);

    vec3  cCenter = texture2D(srcColor, texCoord).rgb;
    float vCenter = texture2D(srcMoment, texCoord).r;
    float dCenter = linearDepth(texture2D(depthtex0, texCoord).r);
    vec3  nCenter = decodeNormal(texture2D(colortex1, texCoord).rgb);

    vec3  sum     = cCenter * h[2];
    float wSum    = h[2];

    for (int x = -2; x <= 2; ++x) {
        for (int y = -2; y <= 2; ++y) {
            if (x == 0 && y == 0) continue;
            vec2  offset = vec2(x, y) * float(step) * texel;
            vec2  sUV    = texCoord + offset;

            vec3  sC = texture2D(srcColor, sUV).rgb;
            float sV = texture2D(srcMoment, sUV).r;
            float sD = linearDepth(texture2D(depthtex0, sUV).r);
            vec3  sN = decodeNormal(texture2D(colortex1, sUV).rgb);

            float w = h[abs(x)] * h[abs(y)];

            // Edge-stopping weights.
            float wZ = exp(-abs(sD - dCenter) * 2.0);
            float wN = pow(max(dot(sN, nCenter), 0.0), 32.0);
            float wV = 1.0 / (1.0 + sqrt(max(sV, 0.0)) * 4.0);

            w *= wZ * wN * wV;
            sum  += sC * w;
            wSum += w;
        }
    }

    vec3 result = sum / max(wSum, 1e-5);
    return vec4(result, 1.0);
}

void main() {
    // Two A-Trous iterations in one pass: step 1 and step 2.
    vec4 pass0 = aTrousPass(colortex4, colortex5, 1);
    vec4 pass1 = aTrousPass(colortex4, colortex5, 2);

    // Cheap ping-pong approximation: blend the two filtered outputs.
    vec3 filtered = mix(pass0.rgb, pass1.rgb, 0.5);

    gl_FragData[0] = vec4(filtered, 1.0); // colortex6 — filtered GI
    gl_FragData[1] = vec4(pass1.rgb * pass1.rgb); // colortex7 — updated moment
}
