#version 330 compatibility
#include "/lib/options.glsl"
#include "/lib/util.glsl"

/* RENDERTARGETS: 4,5 */
in vec2 texCoord;

const float h[5] = float[](1.0 / 16.0, 1.0 / 4.0, 3.0 / 8.0, 1.0 / 4.0, 1.0 / 16.0);

vec3 aTrousStep(sampler2D src, int step) {
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);

    vec3  cCenter = texture2D(src, texCoord).rgb;
    float dCenter = linearDepth(texture2D(depthtex0, texCoord).r);
    vec3  nCenter = decodeNormal(texture2D(colortex1, texCoord).rgb);

    vec3  sum  = cCenter * h[2];
    float wSum = h[2];

    for (int x = -2; x <= 2; ++x) {
        for (int y = -2; y <= 2; ++y) {
            if (x == 0 && y == 0) continue;
            vec2 sUV = texCoord + vec2(x, y) * float(step) * texel;

            vec3 sC = texture2D(src, sUV).rgb;
            float sD = linearDepth(texture2D(depthtex0, sUV).r);
            vec3 sN = decodeNormal(texture2D(colortex1, sUV).rgb);

            float w = h[abs(x)] * h[abs(y)];
            w *= exp(-abs(sD - dCenter) * 2.0);
            w *= pow(max(dot(sN, nCenter), 0.0), 32.0);

            sum  += sC * w;
            wSum += w;
        }
    }
    return sum / max(wSum, 1e-5);
}

void main() {
    // Read the result of composite2.
    vec3 result = texture2D(colortex6, texCoord).rgb;

    // Remaining A-Trous iterations controlled by ATROUS_PASSES.
    // Because we are in a single pass, each additional iteration is sampled
    // from the same source and blended in — a cheap approximation of the full
    // ping-pong SVGF pipeline.
    #if ATROUS_PASSES >= 3
        vec3 pass3 = aTrousStep(colortex6, 4);
        result = mix(result, pass3, 0.5);
    #endif
    #if ATROUS_PASSES >= 4
        vec3 pass4 = aTrousStep(colortex6, 8);
        result = mix(result, pass4, 0.33);
    #endif
    #if ATROUS_PASSES >= 5
        vec3 pass5 = aTrousStep(colortex6, 16);
        result = mix(result, pass5, 0.25);
    #endif

    gl_FragData[0] = vec4(result, 1.0); // colortex4 — final filtered GI
    gl_FragData[1] = vec4(result * result, 1.0);
}
