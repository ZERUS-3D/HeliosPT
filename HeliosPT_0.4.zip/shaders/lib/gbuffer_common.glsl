#ifndef GBUFFER_COMMON_GLSL
#define GBUFFER_COMMON_GLSL

// Minimal include for gbuffers programs.
// IMPORTANT:
//  * gbuffers stages must NOT declare composite-only samplers (colortex3..7).
//  * gbufferModelView / gbufferModelViewInverse are auto-injected by Oculus
//    (redeclaring them triggers C1038 conflicts in this loader version).
//  * near/far are kept declared here — no conflict reported for them and
//    encodeDepth() depends on them.

#include "/lib/options.glsl"

uniform float near;
uniform float far;

vec3 encodeNormal(vec3 n) { return n * 0.5 + 0.5; }
float encodeDepth(float d) { return d / far; }

#endif // GBUFFER_COMMON_GLSL
