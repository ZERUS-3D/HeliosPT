#ifndef UTIL_GLSL
#define UTIL_GLSL

#include "/lib/options.glsl"

// ---------------------------------------------------------------------------
// Uniforms.
// IMPORTANT (Oculus 1.6.4 / Iris): all standard OptiFine uniforms below are
// AUTO-INJECTED by the loader into every program — do NOT redeclare them or
// the driver raises "C1038: declaration conflicts with previous declaration"
// and the whole pipeline silently falls back to fixed-function (vanilla).
//
// Auto-injected, therefore not declared here:
//   frameTimeCounter, frameCounter, worldTime, cameraPosition,
//   previousCameraPosition, sunPosition, moonPosition,
//   gbufferModelView(Inverse), gbufferProjection(Inverse),
//   gbufferPreviousModelView, gbufferPreviousProjection,
//   shadowcolor0/1, shadowtex0/1, depthtex0/1/2, noisetex,
//   viewWidth, viewHeight, aspectRatio, near, far, rainStrength, fogColor...
//
// Generic colortex samplers are NOT auto-injected, so they stay declared.
// ---------------------------------------------------------------------------
uniform sampler2D colortex0;  // albedo
uniform sampler2D colortex1;  // world-space normal
uniform sampler2D colortex2;  // linear depth + material ID
uniform sampler2D colortex3;  // composite buffer
uniform sampler2D colortex4;  // GI radiance
uniform sampler2D colortex5;  // GI second moment
uniform sampler2D colortex6;  // filtered GI / temporal history
uniform sampler2D colortex7;  // history moment

const float SUN_PATH_ROTATION = -40.0;

// ---------------------------------------------------------------------------
// Depth / position helpers
// ---------------------------------------------------------------------------
float linearDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

float encodeDepth(float depth) { return depth / far; }
float decodeDepth(float depth) { return depth * far; }

vec3 encodeNormal(vec3 n) { return n * 0.5 + 0.5; }
vec3 decodeNormal(vec3 n) { return n * 2.0 - 1.0; }

vec3 getWorldPos(vec2 uv, float depth) {
    vec4 ndc  = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * ndc;
    view /= view.w;
    vec4 world = gbufferModelViewInverse * view;
    return world.xyz;
}

vec3 getViewDir(vec2 uv) {
    return normalize(getWorldPos(uv, 0.0));
}

// ---------------------------------------------------------------------------
// Simple frame-coherent hash noise (Pascal-friendly, no texture fetch)
// ---------------------------------------------------------------------------
float interleavedGradientNoise(vec2 uv) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(uv, magic.xy)));
}

#endif // UTIL_GLSL
