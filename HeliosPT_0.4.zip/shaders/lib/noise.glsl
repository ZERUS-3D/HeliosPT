#ifndef NOISE_GLSL
#define NOISE_GLSL

#include "/lib/options.glsl"

// frameTimeCounter / frameCounter are auto-injected by Oculus/Iris.

// ---------------------------------------------------------------------------
// Tiny integer hash. Avoids heavy texture lookups on the Pascal FP32 path.
// ---------------------------------------------------------------------------
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

// ---------------------------------------------------------------------------
// Cosine-weighted hemisphere sampling for diffuse GI bounces.
// ---------------------------------------------------------------------------
vec3 cosineSampleHemisphere(vec3 N, vec2 seed) {
    float r     = sqrt(seed.x);
    float theta = 6.28318530718 * seed.y;

    vec3 T;
    if (abs(N.z) < 0.999) T = normalize(cross(N, vec3(0.0, 0.0, 1.0)));
    else                  T = normalize(cross(N, vec3(0.0, 1.0, 0.0)));
    vec3 B = cross(N, T);

    vec3 local = vec3(r * cos(theta), r * sin(theta), sqrt(max(0.0, 1.0 - seed.x)));
    return local.x * T + local.y * B + local.z * N;
}

vec2 seededNoise(vec2 pix) {
    return hash22(pix + float(frameCounter) * vec2(13.37, 47.11));
}

#endif // NOISE_GLSL
