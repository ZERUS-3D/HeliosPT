#ifndef VOXEL_GLSL
#define VOXEL_GLSL

#include "/lib/options.glsl"

// NOTE: shadowcolor0 and cameraPosition are auto-injected by Oculus/Iris.
// Redeclaring them here caused C1038 conflicts -> do not add them back.

// ---------------------------------------------------------------------------
// Shadow map (voxel atlas) resolution.
// ---------------------------------------------------------------------------
const int shadowMapResolution = 2048;

// ---------------------------------------------------------------------------
// 3D → 2D atlas layout.
// Each Y-slice of the voxel grid is one square tile in the shadow-color map.
//   64  -> 8  tiles -> 512 px
//   96  -> 10 tiles -> 960 px
//   128 -> 12 tiles -> 1536 px
// ---------------------------------------------------------------------------
#if VX_SIZE == 64
  #define VX_TILES 8
#elif VX_SIZE == 96
  #define VX_TILES 10
#else
  #define VX_TILES 12
#endif

#define VX_ATLAS_SIZE (VX_TILES * VX_SIZE)
#define VX_HALF       (VX_SIZE / 2)

struct VoxelHit {
    bool hit;
    vec4 color;
    vec3 normal;
    vec3 pos;
};

// Integer pixel position of a voxel inside the shadow-color atlas.
ivec2 voxelToPixels(ivec3 voxel) {
    int layer = voxel.y;
    ivec2 tile  = ivec2(layer % VX_TILES, layer / VX_TILES);
    ivec2 local = ivec2(voxel.x, voxel.z);
    return tile * VX_SIZE + local;
}

// NDC position used by the geometry shader to rasterize one voxel point.
vec2 voxelToNDC(ivec3 voxel) {
    // +0.5 is mandatory: a 1px point placed exactly on a texel corner lands
    // between four samples and is dropped by the NVIDIA point rasterizer,
    // leaving the whole voxel grid empty.
    vec2 px = vec2(voxelToPixels(voxel)) + 0.5;
    return px / (float(shadowMapResolution) * 0.5) - 1.0;
}

// Normalized UV used when tracing in composite passes (also +0.5 centered).
vec2 voxelToUV(ivec3 voxel) {
    return (vec2(voxelToPixels(voxel)) + 0.5) / float(shadowMapResolution);
}

bool voxelInBounds(ivec3 voxel) {
    return all(greaterThanEqual(voxel, ivec3(0))) &&
           all(lessThan(voxel, ivec3(VX_SIZE)));
}

bool sampleVoxel(ivec3 voxel) {
    return texture2D(shadowcolor0, voxelToUV(voxel)).a > 0.5;
}

// ---------------------------------------------------------------------------
// Integer 3D DDA (Amanatides-Woo). Coordinates are camera-relative "world"
// space, identical to gl_Vertex.xyz in the shadow geometry shader.
// ---------------------------------------------------------------------------
VoxelHit traceVoxelRay(vec3 origin, vec3 dir, bool skipFirst) {
    vec3 camOff = fract(cameraPosition);
    origin += camOff;

    ivec3 mapPos    = ivec3(floor(origin));
    vec3  deltaDist = abs(vec3(length(dir)) / dir);
    ivec3 rayStep   = ivec3(sign(dir));
    vec3  sideDist  = (sign(dir) * (vec3(mapPos) - origin) +
                       (sign(dir) * 0.5) + 0.5) * deltaDist;
    bvec3 mask = bvec3(false);

    for (int i = 0; i < MAX_DDA; ++i) {
        if (!skipFirst || i != 0) {
            ivec3 voxel = mapPos + ivec3(VX_HALF);
            if (voxelInBounds(voxel) && sampleVoxel(voxel)) {
                vec3 normal = -sign(dir) * vec3(mask);
                float dist  = length(vec3(mask) * (sideDist - deltaDist)) / length(dir);
                vec3 hitPos = origin + dir * dist - camOff;
                vec4 color  = texture2D(shadowcolor0, voxelToUV(voxel));
                return VoxelHit(true, color, normal, hitPos);
            }
        }

        mask      = lessThanEqual(sideDist.xyz, min(sideDist.yzx, sideDist.zxy));
        sideDist += vec3(mask) * deltaDist;
        mapPos   += ivec3(vec3(mask)) * rayStep;

        // Escaped the grid: stop early instead of burning all MAX_DDA steps.
        ivec3 centered = mapPos + ivec3(VX_HALF);
        if (any(lessThan(centered, ivec3(0))) ||
            any(greaterThanEqual(centered, ivec3(VX_SIZE)))) {
            break;
        }
    }

    return VoxelHit(false, vec4(0.0), vec3(0.0), vec3(0.0));
}

#endif // VOXEL_GLSL
