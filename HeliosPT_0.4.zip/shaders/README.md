# HeliosPT — lightweight voxel path-tracing shaderpack

**Target pipeline:** Minecraft 1.18.2 · Forge · Embeddium · Oculus (Iris fork)  
**Target GPU class:** NVIDIA Pascal (GTX 1060 / 1070 / 1080 / 1080 Ti) — no RT cores, fast FP32, limited fillrate.

---

## Цель

Стабильные ~60 FPS в 1080p на GTX 1080 при включённой воксельной трассировке путей с диффузным GI, темпоральным накоплением и SVGF-денойзером.

---

## Архитектура

| Этап | Файлы | Что делает |
|------|-------|------------|
| **Voxelization** | `shadow.vsh`, `shadow.gsh`, `shadow.fsh` | Записывает мир в 2D-атлас как 3D-сетку вокселей через geometry shader. |
| **G-buffer** | `gbuffers_terrain.vsh/fsh` | Albedo → `colortex0`, world normal → `colortex1`, depth+material → `colortex2`. |
| **Path tracing** | `composite.vsh/fsh` | Целочисленный 3D DDA (Amanatides-Woo), диффузное GI, 1–2 отскока. |
| **Temporal** | `composite1.fsh` | Reprojection по motion-векторам, накопление истории. |
| **SVGF** | `composite2.fsh`, `composite3.fsh` | A-Trous wavelet filter (3–5 итераций) с edge-stopping по глубине/нормалям. |
| **Post-process** | `final.fsh` | ACES tonemap + жёстко зажатый auto-exposure. |

---

## Пресеты

| Профиль | Воксели | GI | DDA | Bounces | A-Trous | Примерный FPS на GTX 1080 |
|---------|---------|----|-----|---------|---------|---------------------------|
| **LOW** | 64³ | 0.5x | 64 | 1 | 3 | 80–100 |
| **MEDIUM** | 96³ | 0.75x | 64 | 1 + Temporal | 4 | 55–70 |
| **HIGH** | 128³ | 1.0x | 128 | 2 | 5 | 40–55 |

---

## Настройки в игре

- `Voxel Grid` — размер сетки вокселей.
- `GI Resolution` — разрешение буфера GI (0.5x / 0.75x / 1.0x).
- `DDA Step Limit` — максимальное число шагов луча.
- `Max Bounces` — число отскоков diffuse path.
- `A-Trous Passes` — итерации SVGF.
- `Exposure Bias` — смещение экспозиции.
- `Sun Intensity` — яркость солнца.

---

## Важные замечания

1. Это **стартовый каркас**. Некоторые вещи (точная привязка вокселей к блокам, motion vectors, полноценный auto-exposure) требуют доработки под конкретную версию Oculus.
2. `block.properties` назначает ID 1 только распространённым твёрдым блокам. Если блок не вокселизируется — добавьте его в `block.1=...`.
3. Для Pascal важно держать циклы короткими и избегать FP16 — весь тяжёлый math оставлен в FP32.
4. В `shaders.properties` используется условная директива `#if GI_RESOLUTION` для `scale.composite`. Если ваша версия Oculus не поддерживает препроцессор в `shaders.properties`, задайте фиксированный масштаб вручную.
